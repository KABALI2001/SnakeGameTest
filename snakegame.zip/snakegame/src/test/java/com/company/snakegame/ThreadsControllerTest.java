/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.company.snakegame;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ThreadsControllerTest {

    private ThreadsController threadsController;

    @BeforeEach
    public void setUp() {
      
        Window gameWindow = new Window();

        threadsController = new ThreadsController(new Tuple(10, 10));
    }

    @Test
    public void testInitialSnakeSize() {
        assertEquals(3, threadsController.sizeSnake, "Initial snake size should be 3");
    }

    @Test
    public void testInitialSnakePosition() {
        Tuple headPosition = threadsController.positions.get(0);
        assertEquals(10, headPosition.getX(), "Initial X position should be 10");
        assertEquals(10, headPosition.getY(), "Initial Y position should be 10");
    }

    @Test
    public void testFoodSpawned() {
        Tuple foodPosition = threadsController.foodPosition;
        assertNotNull(foodPosition, "Food position should not be null");
    }
}