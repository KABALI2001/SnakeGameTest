/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.company.snakegame;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.awt.event.KeyEvent;
import javax.swing.JButton;

public class KeyboardListenerTest {

    KeyboardListener keyboardListener;
    JButton mockComponent; 

    @BeforeEach
    public void setup() {
        keyboardListener = new KeyboardListener();
        mockComponent = new JButton(); // Initialize mock component
        ThreadsController.directionSnake = 0; // Reset direction before each test
    }

    @Test
    public void testKeyPressed_Right() {
        // Simulate a key press event for the right arrow key
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_RIGHT);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should be set to Right (1)
        assertEquals(1, ThreadsController.directionSnake, "Direction should be set to Right");
    }

    @Test
    public void testKeyPressed_Top() {
        // Simulate a key press event for the up arrow key
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_UP);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should be set to Top (3)
        assertEquals(3, ThreadsController.directionSnake, "Direction should be set to Top");
    }

    @Test
    public void testKeyPressed_Left() {
        // Simulate a key press event for the left arrow key
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_LEFT);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should be set to Left (2)
        assertEquals(2, ThreadsController.directionSnake, "Direction should be set to Left");
    }

    @Test
    public void testKeyPressed_Bottom() {
        // Simulate a key press event for the down arrow key
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_DOWN);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should be set to Bottom (4)
        assertEquals(4, ThreadsController.directionSnake, "Direction should be set to Bottom");
    }

    @Test
    public void testKeyPressed_OtherKey() {
        // Simulate a key press event for a key other than arrow keys (e.g., 'A' key)
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_A);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should remain unchanged (0)
        assertEquals(0, ThreadsController.directionSnake, "Direction should remain unchanged for other keys");
    }

    @Test
    public void testKeyPressed_PreventReverseDirection_RightToLeft() {
        // Set initial direction to Right
        ThreadsController.directionSnake = 1;

        // Simulate a key press event for the left arrow key
        KeyEvent keyEvent = createKeyEvent(KeyEvent.VK_LEFT);
        keyboardListener.keyPressed(keyEvent);

        // Assert that the direction should not change to the opposite direction
        assertEquals(1, ThreadsController.directionSnake, "Direction should not change to the opposite direction");
    }

    // Add similar tests for preventing reverse directions (Left to Right, Top to Bottom, Bottom to Top)

    private KeyEvent createKeyEvent(int keyCode) {
        return new KeyEvent(mockComponent, 0, 0, 0, keyCode, ' ');
    }
}
