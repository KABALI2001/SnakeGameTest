package com.company.snakegame;


import org.junit.Test;
import java.awt.Color;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.Assert.assertEquals;

// Wrapper class for SquarePanel
class SquarePanelWrapper extends SquarePanel {

    public SquarePanelWrapper(Color d) {
        super(d);
    }
    public void changeColor(Color color) {
        super.ChangeColor(color);
    }
}

public class SquarePanelTest {

    @Test
    public void testChangeColor() {
        try {
            // Use reflection to create an instance of SquarePanelWrapper
            Constructor<SquarePanelWrapper> constructor = SquarePanelWrapper.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            SquarePanelWrapper squarePanel = constructor.newInstance();
            
            // Define the expected color
            Color expectedColor = Color.RED;
            
            // Call the wrapper method to change the color
            squarePanel.changeColor(expectedColor);
            
            // Get the background color and assert it matches the expected color
            Color actualColor = squarePanel.getBackground();
            assertEquals(expectedColor, actualColor);
        } catch (NoSuchMethodException | IllegalAccessException | InstantiationException | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
