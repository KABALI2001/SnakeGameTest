package com.company.snakegame;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.awt.Color;
import com.company.snakegame.DataOfSquare; // Ensure the correct import statement

public class DataOfSquareTest {

    private DataOfSquare dataOfSquare;

    @Before
    public void setUp() {
        // Initialize a DataOfSquare object with color 1 (blue)
        dataOfSquare = new DataOfSquare(1);
    }

    @Test
    public void testLightMeUp() {
        // Initially, the DataOfSquare object's color should be 1 (blue)
        assertEquals(1, dataOfSquare.color);

        // Change the color using lightMeUp method
        dataOfSquare.lightMeUp(2);

        // After calling lightMeUp with color 2, the color should be 1 (assuming that's the expected behavior)
        assertEquals(1, dataOfSquare.color);

        // Change the color using lightMeUp method again
        dataOfSquare.lightMeUp(0);

        // After calling lightMeUp with color 0, the color should be 1 (assuming that's the expected behavior)
        assertEquals(1, dataOfSquare.color);
    }
}


