/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.company.snakegame;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.awt.Component;
import javax.swing.JFrame;

public class MainTest {

    @Test
    public void testMain() {
        // Arrange: No need for explicit setup

        // Act: Call the main method to start the application
        Main.main(new String[]{});

        // Assert: Check if a JFrame is currently displayed (the game window should be open)
        boolean isGameWindowOpen = isGameWindowOpen();
        assertTrue(isGameWindowOpen, "The game window should be open");
    }

    // Helper method to check if the game window is open
    private boolean isGameWindowOpen() {
        for (Component component : JFrame.getFrames()) {
            // Check if the component is visible and an instance of the Window class
            if (component.isVisible() && component instanceof Window) {
                return true;
            }
        }
        return false;
    }
}
